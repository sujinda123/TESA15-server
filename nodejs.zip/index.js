var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);


const SerialPort = require('serialport')
const Readline = require('@serialport/parser-readline')
const port = new SerialPort('COM1')

const parser = new Readline()
port.pipe(parser)

// port.write('ROBOT POWER ON\n')

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

io.sockets.on('connection', function (socket) {
    
    parser.on('data', function (data) {
        io.sockets.emit('msgUpdate', data);
    })

    socket.on('chat message', (msg) => {
        io.emit('chat message', msg);
        port.write(msg)
    });

});

http.listen(3000, () => {
  console.log('listening on *:3000');
});